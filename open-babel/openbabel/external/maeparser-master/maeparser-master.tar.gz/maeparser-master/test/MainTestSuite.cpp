#define BOOST_TEST_MODULE mae_reader_test

#include <boost/test/unit_test.hpp>
